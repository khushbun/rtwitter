<!DOCTYPE HTML>

<html>
	<head>
		<title>twitter signup</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
		<link href="assets/lib/jquery.bxslider.css" rel="stylesheet" />
		
		<script src="assets/js/jquery.bxslider.min.js"></script>
	</head>
	<body style="background-color: black; color:#fff;">
		<center>
			<div class="container" style="padding-top:5%;">
				<div class="row">
					<div class="col-sm-12 col-md-12 col-lg-12">
						<span ><img src="assets/images/t.png" alt="" style="border-radius: 50%;" /></span>
					</div>
					<div class="col-sm-12 col-m	d-12 col-lg-12" style="padding-top:5%;">
						<h2>RTcamp Assignment | Twitter Login</h2>
						<p>See your 'Tweets', 'Timeline Tweets' <br/>and 'Followers' after authentication</p>
					</div>
					<div class="col-sm-12 col-md-12 col-lg-12" style="">
						<a href="https://rtwittertest.herokuapp.com/maincontent.php" >
							<button type="button" class="btn btn-primary">Sign In</button>
						</a>
					</div>
				</div>		
			</div>
		</center>
	</body>
</html>